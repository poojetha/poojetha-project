import { describe, it, expect } from 'vitest';
import { ZodError } from 'zod';
import {
  CodeQualityResultSchema,
  TestCoverageResultSchema,
  RefactoringSuggestionSchema,
  CodeQualityResultJSONSchema,
  TestCoverageResultJSONSchema,
  RefactoringSuggestionJSONSchema,
} from '../src/types/analysis-results';
import { ReviewReportSchema, ReviewReportJSONSchema } from '../src/types/report-types';

// ---------- valid fixtures ----------
const validCodeQuality = {
  file: 'src/app.ts',
  issues: [
    {
      line: 12,
      severity: 'high',
      category: 'security',
      description: 'Unsanitized input',
      suggestion: 'Escape the value',
    },
  ],
  overallScore: 80,
  summary: 'Mostly fine.',
};

const validTestCoverage = {
  file: 'src/app.ts',
  hasTests: true,
  testFiles: ['tests/app.test.ts'],
  untestedPaths: [
    {
      type: 'function',
      location: 'parse (line 5)',
      priority: 'high',
      reasoning: 'Core logic',
      suggestedTest: 'Call parse("") and expect an error',
    },
  ],
  coverageEstimate: 60,
  summary: 'Partial coverage.',
};

const validRefactoring = {
  file: 'src/app.ts',
  suggestions: [
    {
      type: 'extract-function',
      location: 'run (lines 1-20)',
      impact: 'medium',
      description: 'Split validation out',
      before: 'function run() {}',
      after: 'function validate() {}',
      benefits: 'Easier to test',
    },
  ],
  summary: 'One opportunity.',
};

const validReport = {
  pullRequest: { owner: 'udacity', repo: 'demo', number: 1 },
  fileReviews: [
    {
      file: 'src/app.ts',
      codeQuality: validCodeQuality,
      testCoverage: validTestCoverage,
      refactorings: validRefactoring,
    },
  ],
  summary: {
    totalFiles: 1,
    overallScore: 80,
    criticalIssues: 0,
    highPriorityTests: 1,
    refactoringOpportunities: 1,
  },
  recommendations: [
    { priority: 'high', category: 'testing', description: 'Add tests', files: ['src/app.ts'] },
  ],
  metadata: {
    analyzedAt: '2026-10-09T00:00:00.000Z',
    duration: 1000,
    agentVersions: { 'code-quality-analyzer': '1.0.0' },
  },
};

describe('CodeQualityResultSchema', () => {
  it('accepts valid data', () => {
    expect(() => CodeQualityResultSchema.parse(validCodeQuality)).not.toThrow();
  });

  it('rejects an invalid severity', () => {
    const bad = structuredClone(validCodeQuality);
    bad.issues[0]!.severity = 'urgent';
    expect(() => CodeQualityResultSchema.parse(bad)).toThrow(ZodError);
  });

  it('rejects an invalid category', () => {
    const bad = structuredClone(validCodeQuality);
    bad.issues[0]!.category = 'vibes';
    expect(() => CodeQualityResultSchema.parse(bad)).toThrow(ZodError);
  });

  it('rejects a missing required field', () => {
    const { summary: _omit, ...bad } = validCodeQuality;
    expect(() => CodeQualityResultSchema.parse(bad)).toThrow(ZodError);
  });

  it('rejects a wrong type for line', () => {
    const bad = structuredClone(validCodeQuality) as any;
    bad.issues[0].line = 'twelve';
    expect(() => CodeQualityResultSchema.parse(bad)).toThrow(ZodError);
  });

  it('accepts an empty issues array', () => {
    expect(() => CodeQualityResultSchema.parse({ ...validCodeQuality, issues: [] })).not.toThrow();
  });

  it('accepts boundary scores 0 and 100', () => {
    expect(() => CodeQualityResultSchema.parse({ ...validCodeQuality, overallScore: 0 })).not.toThrow();
    expect(() => CodeQualityResultSchema.parse({ ...validCodeQuality, overallScore: 100 })).not.toThrow();
  });

  it('rejects scores outside 0-100', () => {
    expect(() => CodeQualityResultSchema.parse({ ...validCodeQuality, overallScore: -1 })).toThrow(ZodError);
    expect(() => CodeQualityResultSchema.parse({ ...validCodeQuality, overallScore: 101 })).toThrow(ZodError);
  });
});

describe('TestCoverageResultSchema', () => {
  it('accepts valid data', () => {
    expect(() => TestCoverageResultSchema.parse(validTestCoverage)).not.toThrow();
  });

  it('accepts no tests with empty arrays and 0% coverage', () => {
    const data = { ...validTestCoverage, hasTests: false, testFiles: [], untestedPaths: [], coverageEstimate: 0 };
    expect(() => TestCoverageResultSchema.parse(data)).not.toThrow();
  });

  it('rejects an invalid priority', () => {
    const bad = structuredClone(validTestCoverage);
    bad.untestedPaths[0]!.priority = 'urgent';
    expect(() => TestCoverageResultSchema.parse(bad)).toThrow(ZodError);
  });

  it('rejects an invalid path type', () => {
    const bad = structuredClone(validTestCoverage);
    bad.untestedPaths[0]!.type = 'module';
    expect(() => TestCoverageResultSchema.parse(bad)).toThrow(ZodError);
  });

  it('rejects coverageEstimate above 100', () => {
    expect(() => TestCoverageResultSchema.parse({ ...validTestCoverage, coverageEstimate: 150 })).toThrow(ZodError);
  });

  it('rejects hasTests that is not a boolean', () => {
    expect(() => TestCoverageResultSchema.parse({ ...validTestCoverage, hasTests: 'yes' })).toThrow(ZodError);
  });
});

describe('RefactoringSuggestionSchema', () => {
  it('accepts valid data', () => {
    expect(() => RefactoringSuggestionSchema.parse(validRefactoring)).not.toThrow();
  });

  it('accepts an empty suggestions array', () => {
    expect(() => RefactoringSuggestionSchema.parse({ ...validRefactoring, suggestions: [] })).not.toThrow();
  });

  it('rejects an invalid suggestion type', () => {
    const bad = structuredClone(validRefactoring);
    bad.suggestions[0]!.type = 'rewrite-everything';
    expect(() => RefactoringSuggestionSchema.parse(bad)).toThrow(ZodError);
  });

  it('rejects an invalid impact', () => {
    const bad = structuredClone(validRefactoring);
    bad.suggestions[0]!.impact = 'huge';
    expect(() => RefactoringSuggestionSchema.parse(bad)).toThrow(ZodError);
  });

  it('rejects a suggestion missing before/after code', () => {
    const bad = structuredClone(validRefactoring) as any;
    delete bad.suggestions[0].before;
    expect(() => RefactoringSuggestionSchema.parse(bad)).toThrow(ZodError);
  });
});

describe('ReviewReportSchema', () => {
  it('accepts a valid full report', () => {
    expect(() => ReviewReportSchema.parse(validReport)).not.toThrow();
  });

  it('accepts a report with no files and no recommendations', () => {
    const empty = { ...validReport, fileReviews: [], recommendations: [] };
    expect(() => ReviewReportSchema.parse(empty)).not.toThrow();
  });

  it('rejects a missing pullRequest', () => {
    const { pullRequest: _omit, ...bad } = validReport;
    expect(() => ReviewReportSchema.parse(bad)).toThrow(ZodError);
  });

  it('rejects a non-numeric PR number', () => {
    const bad = { ...validReport, pullRequest: { ...validReport.pullRequest, number: '1' } };
    expect(() => ReviewReportSchema.parse(bad)).toThrow(ZodError);
  });

  it('rejects an invalid recommendation priority', () => {
    const bad = structuredClone(validReport);
    bad.recommendations[0]!.priority = 'whenever';
    expect(() => ReviewReportSchema.parse(bad)).toThrow(ZodError);
  });

  it('rejects a nested invalid file review', () => {
    const bad = structuredClone(validReport);
    bad.fileReviews[0]!.codeQuality.overallScore = 500;
    expect(() => ReviewReportSchema.parse(bad)).toThrow(ZodError);
  });

  it('safeParse reports success false instead of throwing', () => {
    const result = ReviewReportSchema.safeParse({ nope: true });
    expect(result.success).toBe(false);
  });
});

describe('JSON Schema export (for SDK structured outputs)', () => {
  it('produces serializable object schemas', () => {
    for (const schema of [
      CodeQualityResultJSONSchema,
      TestCoverageResultJSONSchema,
      RefactoringSuggestionJSONSchema,
      ReviewReportJSONSchema,
    ]) {
      expect(schema.type).toBe('object');
      expect(() => JSON.stringify(schema)).not.toThrow();
    }
  });

  it('marks required properties for the code quality schema', () => {
    expect(CodeQualityResultJSONSchema.required).toEqual(
      expect.arrayContaining(['file', 'issues', 'overallScore', 'summary'])
    );
  });

  it('marks required properties for the full report schema', () => {
    expect(ReviewReportJSONSchema.required).toEqual(
      expect.arrayContaining(['pullRequest', 'fileReviews', 'summary', 'recommendations', 'metadata'])
    );
  });

  it('exports score bounds and severity enum', () => {
    const props = CodeQualityResultJSONSchema.properties as Record<string, any>;
    expect(props.overallScore.minimum).toBe(0);
    expect(props.overallScore.maximum).toBe(100);
    expect(props.issues.items.properties.severity.enum).toEqual(
      expect.arrayContaining(['critical', 'high', 'medium', 'low', 'info'])
    );
  });
});
