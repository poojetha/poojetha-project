import 'dotenv/config';
import { describe, it, expect } from 'vitest';
import { CodeReviewOrchestrator } from '../src/orchestrator';
import { ReviewReportSchema } from '../src/types/report-types';

// Integration test: reviews a real public PR (octocat/Hello-World #1).
// It makes real API calls and takes several minutes, so it only runs on request:
//   RUN_INTEGRATION=1 npm test
describe.skipIf(!process.env.RUN_INTEGRATION)('integration: octocat/Hello-World#1', () => {
  it(
    'produces a report that matches the ReviewReport schema',
    async () => {
      const report = await new CodeReviewOrchestrator().reviewPullRequest('octocat', 'Hello-World', 1);
      expect(ReviewReportSchema.safeParse(report).success).toBe(true);
      expect(report.pullRequest).toEqual({ owner: 'octocat', repo: 'Hello-World', number: 1 });
    },
    20 * 60 * 1000
  );
});
