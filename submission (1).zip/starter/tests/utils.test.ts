import { describe, it, expect } from 'vitest';
import {
  withRetry,
  withTimeout,
  ReviewError,
  ErrorCodes,
  formatError,
  isReviewError,
} from '../src/utils/error-handler';
import { RateLimiter } from '../src/utils/rate-limiter';

describe('withRetry', () => {
  it('returns the result when the first attempt succeeds', async () => {
    expect(await withRetry(async () => 'ok', 3, 1)).toBe('ok');
  });

  it('retries transient failures and then succeeds', async () => {
    let calls = 0;
    const result = await withRetry(async () => {
      if (++calls < 3) throw new Error('flaky');
      return 'done';
    }, 3, 5);
    expect(result).toBe('done');
    expect(calls).toBe(3);
  });

  it('throws RETRY_EXHAUSTED after all attempts fail', async () => {
    let calls = 0;
    await expect(
      withRetry(async () => {
        calls++;
        throw new Error('always');
      }, 3, 5)
    ).rejects.toMatchObject({ code: ErrorCodes.RETRY_EXHAUSTED });
    expect(calls).toBe(3);
  });

  it('waits longer between later attempts (exponential backoff)', async () => {
    const stamps: number[] = [];
    await withRetry(async () => {
      stamps.push(Date.now());
      if (stamps.length < 3) throw new Error('flaky');
    }, 3, 40).catch(() => undefined);
    const gap1 = stamps[1]! - stamps[0]!;
    const gap2 = stamps[2]! - stamps[1]!;
    expect(gap1).toBeGreaterThanOrEqual(35);   // ~40ms + jitter
    expect(gap2).toBeGreaterThanOrEqual(75);   // ~80ms + jitter
  });
});

describe('withTimeout', () => {
  it('returns the result when fn finishes in time', async () => {
    expect(await withTimeout(async () => 42, 200)).toBe(42);
  });

  it('throws AGENT_TIMEOUT when fn is too slow', async () => {
    await expect(
      withTimeout(() => new Promise((r) => setTimeout(r, 300)), 50, 'too slow')
    ).rejects.toMatchObject({ code: ErrorCodes.AGENT_TIMEOUT, message: 'too slow' });
  });
});

describe('error helpers', () => {
  it('formats ReviewError with its code', () => {
    const err = new ReviewError('boom', ErrorCodes.UNKNOWN_ERROR);
    expect(isReviewError(err)).toBe(true);
    expect(formatError(err)).toBe('[UNKNOWN_ERROR] boom');
  });

  it('formats plain errors and non-errors', () => {
    expect(formatError(new Error('plain'))).toBe('plain');
    expect(formatError('text')).toBe('text');
  });
});

describe('RateLimiter', () => {
  it('allows requests under the limits', async () => {
    const rl = new RateLimiter({ maxConcurrent: 2 });
    expect(rl.canProceed()).toBe(true);
    await rl.acquire();
    expect(rl.canProceed()).toBe(true);
  });

  it('blocks at the concurrency limit and resumes after release', async () => {
    const rl = new RateLimiter({ maxConcurrent: 1 });
    await rl.acquire();
    expect(rl.canProceed()).toBe(false);

    let second = false;
    const pending = rl.acquire().then(() => { second = true; });
    await new Promise((r) => setTimeout(r, 30));
    expect(second).toBe(false);

    rl.release();
    await pending;
    expect(second).toBe(true);
  });

  it('enforces the requests-per-minute window', async () => {
    const rl = new RateLimiter({ maxRequestsPerMinute: 2, maxConcurrent: 10 });
    await rl.acquire();
    await rl.acquire();
    expect(rl.canProceed()).toBe(false);
    expect(rl.getStatus().availableRequests).toBe(0);
  });

  it('enforces the tokens-per-minute window', async () => {
    const rl = new RateLimiter({ maxTokensPerMinute: 1000, maxConcurrent: 10 });
    await rl.acquire(900);
    expect(rl.canProceed(200)).toBe(false);
    expect(rl.canProceed(100)).toBe(true);
  });

  it('prunes records older than 60 seconds', async () => {
    const rl = new RateLimiter({ maxRequestsPerMinute: 1, maxConcurrent: 10 });
    await rl.acquire();
    expect(rl.canProceed()).toBe(false);
    (rl as any).requestHistory[0].timestamp = Date.now() - 61000;
    expect(rl.canProceed()).toBe(true);
  });

  it('updates token usage on release', async () => {
    const rl = new RateLimiter();
    await rl.acquire(1000);
    rl.release(250);
    expect(rl.getStatus().tokensInWindow).toBe(250);
  });
});
