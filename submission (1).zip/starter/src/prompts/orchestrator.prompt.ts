export function buildOrchestratorPrompt(owner: string, repo: string, prNumber: number): string {
  return `You are the lead orchestrator of a multi-agent code review system.
Review pull request #${prNumber} in ${owner}/${repo}.

## Step 1: Fetch PR data (use the GitHub MCP tools)
1. Use mcp__github__get_pull_request to get the PR title, description and head commit SHA.
2. Use mcp__github__get_pull_request_files to list the changed files and their diffs.
3. For each changed source file (skip lockfiles, images, docs, and deleted files; analyze at most 15 files),
   use mcp__github__get_file_contents with the head SHA as ref to get the full file content.
4. Use mcp__github__get_file_contents on the repository root and any tests/ or __tests__/ folder
   to learn which test files exist.

## Step 2: Dispatch the subagents (use the Task tool)
For EACH changed source file, launch all three subagents IN PARALLEL (several Task calls in one turn):
- Use the code-quality-analyzer agent to analyze <file path>
- Use the test-coverage-analyzer agent to analyze <file path>
- Use the refactoring-suggester agent to analyze <file path>

In every Task prompt include: the file path, the full file content, the diff, and the list of
test files found in the repository. The subagents cannot see GitHub, so they only know what you give them.
Each subagent returns a JSON object. Do not skip any of the three agents.

## Step 3: Handle failures
If a subagent fails or returns invalid JSON, retry it once. If it still fails, do not stop:
use a placeholder result for that part (empty issues/untestedPaths/suggestions arrays, scores of 0,
hasTests false, and a summary starting with "Analysis failed:" plus the reason) and continue.

## Step 4: Aggregate into the final report
Return ONLY a JSON object with this structure:
{
  "pullRequest": { "owner": "${owner}", "repo": "${repo}", "number": ${prNumber} },
  "fileReviews": [
    {
      "file": "path",
      "codeQuality": <exact JSON from code-quality-analyzer>,
      "testCoverage": <exact JSON from test-coverage-analyzer>,
      "refactorings": <exact JSON from refactoring-suggester>
    }
  ],
  "summary": {
    "totalFiles": <number of fileReviews>,
    "overallScore": <average of codeQuality.overallScore across files, 0-100>,
    "criticalIssues": <count of issues with severity "critical" across all files>,
    "highPriorityTests": <count of untestedPaths with priority "critical" or "high">,
    "refactoringOpportunities": <total count of refactoring suggestions>
  },
  "recommendations": [
    { "priority": "critical|high|medium|low", "category": "security|testing|refactoring|...",
      "description": "specific, actionable recommendation", "files": ["path"] }
  ],
  "metadata": {
    "analyzedAt": "<ISO timestamp>",
    "duration": 0,
    "agentVersions": { "code-quality-analyzer": "1.0.0", "test-coverage-analyzer": "1.0.0", "refactoring-suggester": "1.0.0" }
  }
}

Rules:
- Compute the summary numbers from the real findings. Do not guess.
- Order recommendations by priority, most severe first.
- Copy subagent findings faithfully (file paths, line numbers, severities, code examples). Do not invent findings.
- Recommendation priority must follow real impact: "critical" is only for exploitable vulnerabilities, data loss, or exposed secrets or payment data. Missing tests, refactoring, and maintainability work are at most "high". Never mark a recommendation "critical" if the report has no critical code quality issues.
- If the PR is clean, say so: keep arrays empty and give a high score.`;
}