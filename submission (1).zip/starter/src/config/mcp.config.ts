export const mcpServersConfig = {
  /**
   * GitHub MCP Server
   * The server expects GITHUB_PERSONAL_ACCESS_TOKEN, so we map our
   * GITHUB_TOKEN from .env to that name. The token is optional but
   * recommended for higher rate limits.
   */
  github: {
    type: 'stdio' as const,
    command: 'npx',
    args: ['-y', '@modelcontextprotocol/server-github'],
    env: {
      GITHUB_PERSONAL_ACCESS_TOKEN: process.env.GITHUB_TOKEN || '',
    },
  },

  /**
   * ESLint MCP Server
   * Runs locally and needs no authentication.
   */
  eslint: {
    type: 'stdio' as const,
    command: 'npx',
    args: ['-y', '@eslint/mcp@latest'],
    env: {},
  },
};
