import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { REFACTORING_SUGGESTER_PROMPT } from '../prompts/refactoring-suggester.prompt.js';

export const refactoringSuggester: AgentDefinition = {
  description:
    'Suggests structural improvements for a changed source file: extract function, rename, ' +
    'modernize syntax, simplify logic, remove dead code, apply design patterns. Use for every ' +
    'changed code file. Returns suggestions with before/after code.',
  prompt: REFACTORING_SUGGESTER_PROMPT,
  tools: ['Read', 'Grep', 'Glob', 'Skill'],
  model: 'inherit',
};