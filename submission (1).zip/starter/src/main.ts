import 'dotenv/config'; // must stay first so .env is loaded before other modules read process.env
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { CodeReviewOrchestrator } from './orchestrator.js';
import { ReportGenerator, logger, formatError, ReviewError, ErrorCodes } from './utils/index.js';

const USAGE = `Usage: npm run dev -- <owner> <repo> <pr-number>
Example: npm run dev -- udacity cd14715-simple-todo-app 1`;

interface CliArgs {
  owner: string;
  repo: string;
  prNumber: number;
}

/** Validate command-line arguments (argv[0] is node, argv[1] is the script). */
function parseArgs(argv: string[]): CliArgs {
  const [owner, repo, prArg] = argv;

  if (!owner || !repo || !prArg) {
    throw new ReviewError(
      `Missing arguments. Expected 3 (owner, repo, PR number).\n${USAGE}`,
      ErrorCodes.INVALID_CONFIG
    );
  }
  if (!/^[1-9]\d*$/.test(prArg)) {
    throw new ReviewError(
      `PR number must be a positive integer, got "${prArg}".\n${USAGE}`,
      ErrorCodes.INVALID_CONFIG
    );
  }
  return { owner, repo, prNumber: parseInt(prArg, 10) };
}

/** Check credentials: Anthropic API key OR AWS Bedrock credentials. */
function validateAuthentication(): void {
  const hasAnthropicKey = Boolean(process.env.ANTHROPIC_API_KEY);
  const hasAwsKeys = Boolean(process.env.AWS_ACCESS_KEY_ID && process.env.AWS_SECRET_ACCESS_KEY);

  if (hasAnthropicKey) {
    logger.info('Authentication: using Anthropic API key');
  } else if (hasAwsKeys) {
    if (!process.env.AWS_REGION) {
      throw new ReviewError(
        'AWS credentials found but AWS_REGION is not set. Add AWS_REGION=us-east-1 (or your region) to .env.',
        ErrorCodes.MISSING_API_KEY
      );
    }
    logger.info(`Authentication: using AWS Bedrock (region ${process.env.AWS_REGION})`);
  } else {
    throw new ReviewError(
      'No credentials found. Set ANTHROPIC_API_KEY, or set AWS_ACCESS_KEY_ID, ' +
        'AWS_SECRET_ACCESS_KEY and AWS_REGION. (In Vocareum, ANTHROPIC_API_KEY is already set in the workspace.)',
      ErrorCodes.MISSING_API_KEY
    );
  }

  if (!process.env.GITHUB_TOKEN) {
    logger.warn('GITHUB_TOKEN is not set. Public repos still work, but GitHub rate limits are much lower.');
  }
}

/** Check the model name and explain the expected format if it is missing. */
function validateModel(): void {
  if (!process.env.ANTHROPIC_MODEL) {
    throw new ReviewError(
      'ANTHROPIC_MODEL is not set. Add it to .env, for example:\n' +
        '  Anthropic API: ANTHROPIC_MODEL=claude-sonnet-4-5-20250929\n' +
        '  AWS Bedrock:   ANTHROPIC_MODEL=us.anthropic.claude-sonnet-4-5-20250929-v1:0',
      ErrorCodes.INVALID_CONFIG
    );
  }
}

/** Write the report in all three formats and return the file paths. */
async function saveReports(
  report: Parameters<ReportGenerator['generateJSONReport']>[0],
  owner: string,
  repo: string,
  prNumber: number
): Promise<string[]> {
  const outputDir = path.resolve(process.env.PROJECT_ROOT ?? process.cwd(), 'reports');
  await mkdir(outputDir, { recursive: true });

  const generator = new ReportGenerator();
  const baseName = `${owner}_${repo}_${prNumber}`;

  const files: Array<[string, string]> = [
    [`${baseName}.json`, generator.generateJSONReport(report)],
    [`${baseName}.md`, generator.generateMarkdownReport(report)],
    [`${baseName}.html`, generator.generateHTMLReport(report)],
  ];

  const saved: string[] = [];
  for (const [fileName, content] of files) {
    const filePath = path.join(outputDir, fileName);
    await writeFile(filePath, content, 'utf8');
    saved.push(filePath);
  }
  return saved;
}

async function main(): Promise<void> {
  const { owner, repo, prNumber } = parseArgs(process.argv.slice(2));
  validateAuthentication();
  validateModel();

  logger.info(`Reviewing ${owner}/${repo}#${prNumber} ... this usually takes a few minutes`);

  const orchestrator = new CodeReviewOrchestrator();
  const report = await orchestrator.reviewPullRequest(owner, repo, prNumber);

  const savedFiles = await saveReports(report, owner, repo, prNumber);

  logger.info('Review complete.');
  logger.info(
    `Score ${report.summary.overallScore}/100 | files ${report.summary.totalFiles} | ` +
      `critical issues ${report.summary.criticalIssues} | high-priority test gaps ${report.summary.highPriorityTests} | ` +
      `refactorings ${report.summary.refactoringOpportunities}`
  );
  for (const file of savedFiles) {
    logger.info(`Saved: ${file}`);
  }
}

main().catch((error: unknown) => {
  // Friendly message only, no stack trace
  console.error(`\nError: ${formatError(error)}`);
  process.exit(1);
});
