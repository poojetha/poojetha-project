import { query } from '@anthropic-ai/claude-agent-sdk';
import {
  ReviewReportSchema,
  ReviewReportJSONSchema,
  type ReviewReport,
} from './types/report-types.js';
import { mcpServersConfig } from './config/mcp.config.js';
import { codeQualityAnalyzer, testCoverageAnalyzer, refactoringSuggester } from './agents/index.js';
import { buildOrchestratorPrompt } from './prompts/index.js';
import {
  withRetry,
  withTimeout,
  globalRateLimiter,
  ReviewError,
  ErrorCodes,
} from './utils/index.js';

export interface OrchestratorOptions {
  model?: string;
  maxTurns?: number;
  projectRoot?: string;
  /** Max time for one review attempt, in milliseconds (default 25 minutes) */
  timeoutMs?: number;
}

export class CodeReviewOrchestrator {
  private readonly model: string;
  private readonly maxTurns: number;
  private readonly projectRoot: string;
  private readonly timeoutMs: number;

  constructor(options: OrchestratorOptions = {}) {
    const model = options.model ?? process.env.ANTHROPIC_MODEL;
    if (!model) {
      throw new ReviewError(
        'ANTHROPIC_MODEL is not set. Add it to your .env file.',
        ErrorCodes.INVALID_CONFIG
      );
    }
    this.model = model;
    this.maxTurns = options.maxTurns ?? 60;
    this.projectRoot = options.projectRoot ?? process.env.PROJECT_ROOT ?? process.cwd();
    this.timeoutMs = options.timeoutMs ?? 25 * 60 * 1000;
  }

  /**
   * Review a pull request. Wraps the real work with rate limiting,
   * a timeout and retry with exponential backoff.
   */
  async reviewPullRequest(owner: string, repo: string, prNumber: number): Promise<ReviewReport> {
    await globalRateLimiter.acquire(20000);
    try {
      return await withRetry(
        () =>
          withTimeout(
            () => this.runReview(owner, repo, prNumber),
            this.timeoutMs,
            `Review of ${owner}/${repo}#${prNumber} timed out after ${this.timeoutMs / 1000}s`
          ),
        2, // at most 2 attempts, since each attempt costs real API usage
        2000
      );
    } catch (error) {
      if (error instanceof ReviewError) throw error;
      throw new ReviewError(
        error instanceof Error ? error.message : String(error),
        ErrorCodes.AGENT_FAILED
      );
    } finally {
      globalRateLimiter.release();
    }
  }

  private async runReview(owner: string, repo: string, prNumber: number): Promise<ReviewReport> {
    const startedAt = Date.now();
    const invokedAgents = new Set<string>();
    let structuredOutput: unknown;
    let resultText = '';

    for await (const message of query({
      prompt: buildOrchestratorPrompt(owner, repo, prNumber),
      options: {
        model: this.model,
        cwd: this.projectRoot,
        settingSources: ['project'], // loads .claude/skills so the Skill tool works
        mcpServers: mcpServersConfig,
        agents: {
          'code-quality-analyzer': codeQualityAnalyzer,
          'test-coverage-analyzer': testCoverageAnalyzer,
          'refactoring-suggester': refactoringSuggester,
        },
        allowedTools: [
          'Task',
          'Skill',
          'Read',
          'Grep',
          'Glob',
          'mcp__github__get_pull_request',
          'mcp__github__get_pull_request_files',
          'mcp__github__get_file_contents',
          'mcp__eslint__lint-files',
        ],
        disallowedTools: ['Bash', 'Write', 'Edit', 'WebFetch'],
        maxTurns: this.maxTurns,
        outputFormat: { type: 'json_schema', schema: ReviewReportJSONSchema },
      },
    })) {
      // --- progress logging ---
      if (message.type === 'system' && message.subtype === 'init') {
        console.log('MCP servers:', JSON.stringify(message.mcp_servers));
      }

      if (message.type === 'assistant' && Array.isArray(message.message.content)) {
        for (const block of message.message.content) {
          if (block.type === 'tool_use') {
            console.log(`-> tool: ${block.name}`);
            if (block.name === 'Task') {
              const input = block.input as { subagent_type?: string };
              if (input.subagent_type) invokedAgents.add(input.subagent_type);
            }
          }
          if (block.type === 'text' && block.text.trim()) {
            console.log(`[assistant] ${block.text.slice(0, 120)}`);
          }
        }
      } else if (message.type === 'result') {
        if (message.subtype !== 'success') {
          throw new ReviewError(
            `Review did not complete (${message.subtype}). Try raising maxTurns or check the logs.`,
            ErrorCodes.AGENT_FAILED,
            { subtype: message.subtype }
          );
        }
        structuredOutput = message.structured_output;
        resultText = message.result;
      }
    }

    console.log(`Subagents invoked: ${[...invokedAgents].join(', ') || 'none'}`);

    // Fall back to parsing the text result if structured_output is missing
    if (structuredOutput === undefined && resultText) {
      try {
        structuredOutput = JSON.parse(resultText);
      } catch {
        /* handled below */
      }
    }
    if (structuredOutput === undefined) {
      throw new ReviewError(
        'The orchestrator returned no structured output.',
        ErrorCodes.STRUCTURED_OUTPUT_FAILED
      );
    }

    const parsed = ReviewReportSchema.safeParse(structuredOutput);
    if (!parsed.success) {
      const details = parsed.error.issues
        .map((i) => `${i.path.join('.')}: ${i.message}`)
        .join('; ');
      throw new ReviewError(
        `Report failed schema validation: ${details}`,
        ErrorCodes.VALIDATION_FAILED
      );
    }

    // Compute summary numbers in code from the real findings (don't trust model arithmetic)
    const data = parsed.data;
    const reviews = data.fileReviews;
    const scores = reviews.map((r) => r.codeQuality.overallScore);

    const summary = {
      totalFiles: reviews.length,
      overallScore: scores.length
        ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length)
        : 0,
      criticalIssues: reviews
        .flatMap((r) => r.codeQuality.issues)
        .filter((i) => i.severity === 'critical').length,
      highPriorityTests: reviews
        .flatMap((r) => r.testCoverage.untestedPaths)
        .filter((p) => p.priority === 'critical' || p.priority === 'high').length,
      refactoringOpportunities: reviews.reduce(
        (count, r) => count + r.refactorings.suggestions.length,
        0
      ),
    };

    // Enforce priority calibration in code: "critical" is reserved for real
    // critical findings, and testing/refactoring/maintainability advice tops out at "high".
    const priorityRank = { critical: 0, high: 1, medium: 2, low: 3 } as const;
    const recommendations = data.recommendations
      .map((rec) => {
        const isNonSecurityAdvice = /test|refactor|maintain|style|doc/i.test(rec.category);
        const noCriticalFindings = summary.criticalIssues === 0;
        if (rec.priority === 'critical' && (isNonSecurityAdvice || noCriticalFindings)) {
          return { ...rec, priority: 'high' as const };
        }
        return rec;
      })
      .sort((a, b) => priorityRank[a.priority] - priorityRank[b.priority]); // most severe first

    // Replace model-supplied timing with the real values
    return {
      ...data,
      summary,
      recommendations,
      metadata: {
        ...data.metadata,
        analyzedAt: new Date().toISOString(),
        duration: Date.now() - startedAt,
      },
    };
  }
}
